Pesan Kontak Baru

Nama: {{ $data['name'] }}
Email: {{ $data['email'] }}
Subjek: {{ $data['subject'] }}

Pesan:
{{ $data['message'] }}
