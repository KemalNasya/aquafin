<?php $__env->startSection('title', 'Home - Company Name'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Hero Section -->

    <?php if (isset($component)) { $__componentOriginal7148f0f889bac4df853ac91166bfc9ae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7148f0f889bac4df853ac91166bfc9ae = $attributes; } ?>
<?php $component = App\View\Components\HeroSection::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('hero-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\HeroSection::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7148f0f889bac4df853ac91166bfc9ae)): ?>
<?php $attributes = $__attributesOriginal7148f0f889bac4df853ac91166bfc9ae; ?>
<?php unset($__attributesOriginal7148f0f889bac4df853ac91166bfc9ae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7148f0f889bac4df853ac91166bfc9ae)): ?>
<?php $component = $__componentOriginal7148f0f889bac4df853ac91166bfc9ae; ?>
<?php unset($__componentOriginal7148f0f889bac4df853ac91166bfc9ae); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalaa1dc9a2adb4589988536ab9fa557489 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa1dc9a2adb4589988536ab9fa557489 = $attributes; } ?>
<?php $component = App\View\Components\AboutSection::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('about-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AboutSection::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa1dc9a2adb4589988536ab9fa557489)): ?>
<?php $attributes = $__attributesOriginalaa1dc9a2adb4589988536ab9fa557489; ?>
<?php unset($__attributesOriginalaa1dc9a2adb4589988536ab9fa557489); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa1dc9a2adb4589988536ab9fa557489)): ?>
<?php $component = $__componentOriginalaa1dc9a2adb4589988536ab9fa557489; ?>
<?php unset($__componentOriginalaa1dc9a2adb4589988536ab9fa557489); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal1e27cc23b4c4846b1bf921f0b76cff06 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1e27cc23b4c4846b1bf921f0b76cff06 = $attributes; } ?>
<?php $component = App\View\Components\InfrastructureSection::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('infrastructure-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\InfrastructureSection::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1e27cc23b4c4846b1bf921f0b76cff06)): ?>
<?php $attributes = $__attributesOriginal1e27cc23b4c4846b1bf921f0b76cff06; ?>
<?php unset($__attributesOriginal1e27cc23b4c4846b1bf921f0b76cff06); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1e27cc23b4c4846b1bf921f0b76cff06)): ?>
<?php $component = $__componentOriginal1e27cc23b4c4846b1bf921f0b76cff06; ?>
<?php unset($__componentOriginal1e27cc23b4c4846b1bf921f0b76cff06); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal80efc3bdb0513c7e339bf592e5defd3a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal80efc3bdb0513c7e339bf592e5defd3a = $attributes; } ?>
<?php $component = App\View\Components\ArticleSection::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('article-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ArticleSection::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal80efc3bdb0513c7e339bf592e5defd3a)): ?>
<?php $attributes = $__attributesOriginal80efc3bdb0513c7e339bf592e5defd3a; ?>
<?php unset($__attributesOriginal80efc3bdb0513c7e339bf592e5defd3a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal80efc3bdb0513c7e339bf592e5defd3a)): ?>
<?php $component = $__componentOriginal80efc3bdb0513c7e339bf592e5defd3a; ?>
<?php unset($__componentOriginal80efc3bdb0513c7e339bf592e5defd3a); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal1fcd9fe4281fc9410fec9e163ae502f4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1fcd9fe4281fc9410fec9e163ae502f4 = $attributes; } ?>
<?php $component = App\View\Components\GallerySection::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('gallery-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GallerySection::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1fcd9fe4281fc9410fec9e163ae502f4)): ?>
<?php $attributes = $__attributesOriginal1fcd9fe4281fc9410fec9e163ae502f4; ?>
<?php unset($__attributesOriginal1fcd9fe4281fc9410fec9e163ae502f4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1fcd9fe4281fc9410fec9e163ae502f4)): ?>
<?php $component = $__componentOriginal1fcd9fe4281fc9410fec9e163ae502f4; ?>
<?php unset($__componentOriginal1fcd9fe4281fc9410fec9e163ae502f4); ?>
<?php endif; ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\website-Pereng Mina GAP\Pereng Mina GAP\resources\views/welcome.blade.php ENDPATH**/ ?>