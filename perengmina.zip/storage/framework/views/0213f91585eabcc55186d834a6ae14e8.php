Pesan Kontak Baru

Nama: <?php echo e($data['name']); ?>

Email: <?php echo e($data['email']); ?>

Subjek: <?php echo e($data['subject']); ?>


Pesan:
<?php echo e($data['message']); ?>

<?php /**PATH D:\website-Pereng Mina GAP\Pereng Mina GAP\resources\views/emails/contact.blade.php ENDPATH**/ ?>