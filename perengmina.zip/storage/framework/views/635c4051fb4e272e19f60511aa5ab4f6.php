<div <?php echo e($attributes->class(['fi-dropdown-list'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH D:\website-Pereng Mina GAP\Pereng Mina GAP\resources\views/vendor/filament/components/dropdown/list/index.blade.php ENDPATH**/ ?>